import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WINDOW_PROVIDERS } from './window-service';
import { BingApiLoaderService } from './bingmap-api-loader-service';
import { MapChartWidgetDirective } from './map-directive';
import { WidgetcomponentComponent } from './widgetcomponent/widgetcomponent.component';
import { WidgetModule } from './widgetcomponent/widget.module';

@NgModule({
  declarations: [
    AppComponent,
     
  ],
  imports: [
    BrowserModule,
    WidgetModule
  ],
  providers: [
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
