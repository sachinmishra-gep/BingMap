import {
    Directive, Input, ElementRef, Renderer2, OnInit,
    AfterViewInit, Inject, OnDestroy, EventEmitter, Output
} from '@angular/core';
import { BingApiLoaderService } from './bingmap-api-loader-service';


declare var Microsoft: any;

@Directive({
    selector: '[map-chart-widget]',
})
export class MapChartWidgetDirective implements OnInit, AfterViewInit, OnDestroy {

    /* 
     *  This report identifier directive let the user know the type ofReports
     * 
     */
    @Input() config: any;
    @Output() mapChartEvents: EventEmitter<any> = new EventEmitter<any>();
    private _bingMap: any;
    private _bingSearchManager;
    private _bingInfobox;
    private _masterMapChartRecords;
    private _mapChartData = [];
    private _chartOptions = {
        maxHeight: 300,
        barWidth: 5,
        pieChart: {
            minRadius: 5,
            maxRadius: 60,
        },
        colors: [],
        legend: [],
        strokeThickness: 0.5,
        strokeColor: '#666666'
    };
    private isMapChartDrillDownEnabled: boolean = false;
    constructor(
        private _element: ElementRef,
        private _renderer: Renderer2,
        private _bingApiLoaderService: BingApiLoaderService,

    ) {

    }

    ngOnInit() {
        debugger;

        this.config.config.createBingMapChart = this.createBingMapChart.bind(this);


    }
    ngAfterViewInit() {
        debugger;
        const identifier = this._renderer.createElement('div');
        identifier.id = `map-chart-container-${this.config.config.cardId}`;
        this._renderer.appendChild(this._element.nativeElement, identifier);
        this._bingApiLoaderService.LoadMaps().then((resolve) => {
            this.createBingMapChart();
        })
    }

    ngOnDestroy() {

    }

    private enableDrilldownOption() {
        const thisRef = this;
        const cardId = this.config.cardId;
        if (this.config.reportDetails.lstReportObjectOnRow.length > 1) {
            const enableDrilldown = this._renderer.createElement('div');
            enableDrilldown.id = `show-enabled-drilldown-${cardId}`;
            enableDrilldown.innerHTML = `
               <div id='drilldown-option-${cardId}' style='text-align:right;padding-right:5px;'>    
                    <input id='show-drilldown-checkbox-${cardId}' type='checkbox' class='filled-in'></input>
                    <label for='Enable Drill down'>Enable Drill down</label>
               </div>         
        `;
            this._renderer.appendChild(this._element.nativeElement, enableDrilldown);
            thisRef.setMapChartDrillCheckboxState(cardId);
            //Adding the checkbox click event
            document.getElementById(`drilldown-option-${cardId}`)
                .addEventListener('click', function () {
                    thisRef.isMapChartDrillDownEnabled = !thisRef.isMapChartDrillDownEnabled;
                    thisRef.setMapChartDrillCheckboxState(cardId);
                });
        }
    }

    private setMapChartDrillCheckboxState(cardId: any) {
        const showDrillDownOption = document.getElementById(`show-drilldown-checkbox-${cardId}`);
        if (showDrillDownOption != null && showDrillDownOption != undefined) {
            if (this.isMapChartDrillDownEnabled) {
                showDrillDownOption.setAttribute('checked', 'checked');
            }
            else {

                showDrillDownOption.removeAttribute('checked');
            }
            this.config.reportDetails.reportProperties["isMapChartDrillDownEnabled"] = this.isMapChartDrillDownEnabled;
        }
    }


    //Preparing the map chart container for the bing maps.
    public createBingMapChart() {
        return new Promise((resolve, reject) => {
            //console.log("Loading");
            const _mapChartContainer = document.getElementById(`map-chart-container-${this.config.config.cardId}`);
            const thisRef = this;
            if (_mapChartContainer != null) {
                var serviceCallCount = 0;
                _mapChartContainer.style.zIndex = "2";
                var plotingLocations = [];
                if (!this._bingMap) {
                    this._bingMap = new Microsoft.Maps.Map(
                        _mapChartContainer, {
                            zoom: 0,
                            disableBirdseye: true,
                            navigationBarMode: Microsoft.Maps.NavigationBarMode.compact,
                            supportedMapTypes: [
                                Microsoft.Maps.MapTypeId.road,
                                Microsoft.Maps.MapTypeId.aerial,
                                Microsoft.Maps.MapTypeId.grayscale,
                                Microsoft.Maps.MapTypeId.canvasLight,
                            ]
                        } as any);
                }
                this._bingMap = this._bingMap;
                resolve(true);
                // thisRef.getSearchManager().then((_response) => {
                //     if (_response) {
                //         thisRef._bingInfobox = new Microsoft.Maps.Infobox(thisRef._bingMap.getCenter(), {
                //             //offset: new Microsoft.Maps.Point(0, 10),
                //             visible: false
                //         } as any);
                //         thisRef._bingInfobox.setMap(thisRef._bingMap);
                //         var interval = setInterval(function () {
                //             if (thisRef._bingMap["_mapHasLoaded"] === true) {
                //                 //console.log('Loaded', thisRef.config.config);
                //                 MapChartSeriesDataPerpation();
                //                 plotChartsOnBingMaps();
                //                 resolve(true);
                //                 //plot();
                //                 //plotFilledMapOnBingMaps();   
                //                 clearInterval(interval);
                //             }
                //         }, 100);
                //     }
                // });
            }
            function MapChartSeriesDataPerpation() {
                thisRef._masterMapChartRecords = thisRef.config.config.series;
            }

            function plotChartsOnBingMaps() {
                thisRef._bingMap.entities.clear();
                //'Italy', 'Maharashtra', 'nepal', 'iraq', 'Africa', 'Australia', 'karachi', 'Hyderabad', 'Chile', 'North America', 'Russia', 'Hubei', 'South Africa'
                plotingLocations = [];
                thisRef._mapChartData = [];
                thisRef._chartOptions.legend = [];
                if (thisRef._masterMapChartRecords) {
                    thisRef._masterMapChartRecords.map(function (value, index) {
                        if (thisRef._chartOptions.legend.length == 0 && value.legend) {
                            thisRef._chartOptions.legend = value.legend;
                        }
                        plotingLocations.push(value.name);
                        thisRef._mapChartData.push({
                            name: value.name,
                            mainName: value.name,
                            values: value.values,
                            legends: thisRef.config.config.series[index].legend
                        });
                    });
                    plotingLocations.forEach(function (value) {
                        let geocodeRequest = {
                            where: value,
                            callback: function (e) {
                                getSuccessBoundaryForCharts(e, value);
                            },
                            errorCallback: function (e) {
                                getErrorBoundaryForCharts(e, value);
                            }
                        };
                        thisRef._bingSearchManager.geocode(geocodeRequest);
                    });
                }
            }

            function getSuccessBoundaryForCharts(response, value) {
                serviceCallCount++;
                plotingCall(response, value).then((_response: any) => {
                    if (_response) {
                        if (serviceCallCount == plotingLocations.length) {
                            //console.log('Success Resolved Request');
                            thisRef.plotBingMaps();
                        }
                    }
                });

            }

            function getErrorBoundaryForCharts(response, value) {
                serviceCallCount++;
                if (serviceCallCount == plotingLocations.length) {
                    //console.log('Error Resolved Request');
                    thisRef.plotBingMaps();
                }
            }

            function plotingCall(response, value) {
                return new Promise((resolve, reject) => {
                    var _locationInfo = response.results[0].location;
                    thisRef._mapChartData.map((mapChartRecValue, key) => {
                        if (mapChartRecValue.name.toLowerCase() == value.toLowerCase()) {
                            thisRef._mapChartData[key]['loc'] = { latitude: _locationInfo.latitude, longitude: _locationInfo.longitude };
                            resolve(true);
                        }
                    });
                });
            }
        });
    }

    // Loading the Search Manager for the bing maps dynamically
    private getSearchManager() {
        const thisRef = this;
        return new Promise((resolve, reject) => {
            if (!thisRef._bingSearchManager) {
                //Load the Bing Spatial Data Services and Search modules, then create an instance of the search manager.
                Microsoft.Maps.loadModule(['Microsoft.Maps.SpatialDataService',
                    'Microsoft.Maps.Search'], function () {
                        thisRef._bingSearchManager = new Microsoft.Maps.Search.SearchManager(thisRef._bingMap);
                        resolve(true);
                    });
            }
            else {
                // search manager has been already defined and present in object.
                resolve(true);
            }
        });
    }

    // Ploting the bing maps dunamicaaly based upon the JSON data.
    private plotBingMaps() {
        const thisRef = this;
        const reportDetails: any = thisRef.config.reportDetails;
        const _bingMapChartType: any = reportDetails.reportProperties;
        const _valueList: any = reportDetails.lstReportObjectOnValue,
            _columnList: any = reportDetails.lstReportObjectOnColumn,
            _rowList: any = reportDetails.lstReportObjectOnRow;
        //Create a layer for the data.
        thisRef._bingMap.layers.clear();
        var layer = new Microsoft.Maps.Layer();
        var i, maxValue = 0;
        //Loop through the  data and calculate the max total value so that pushpins can be scaled relatively.
        if (_valueList.length != 0) {
            for (i = 0; i < thisRef._mapChartData.length; i++) {
                var val = thisRef._mapChartData[i].values.reduce(function (sum, value) {
                    return sum + value;
                });
                //While we are at it, lets cache the total value of each group for faster calculations later.
                thisRef._mapChartData[i].total = val;
                if (val > maxValue) {
                    maxValue = val;
                }
            }
        }

        //Loop through the mock data and create pushpins.
        for (i = 0; i < thisRef._mapChartData.length; i++) {
            if (thisRef._mapChartData[i].loc)
                if (_columnList.length == 0 && _valueList.length == 0) {
                    layer.add(createSinglePushpin(thisRef._mapChartData[i], maxValue));
                }
                else {
                    if (_bingMapChartType && _bingMapChartType != "null" && _bingMapChartType.bingMapChartType == "2") //column
                        layer.add(createColumnChartPushpin(thisRef._mapChartData[i], maxValue));
                    else
                        layer.add(createPieChartPushpin(thisRef._mapChartData[i], maxValue));
                }
        }

        //Add a click handler to the layer.
        Microsoft.Maps.Events.addHandler(layer, 'mouseout', displayInfoboxMouseOut);
        Microsoft.Maps.Events.addHandler(layer, 'mouseover', displayInfoboxMouseOver);
        // Microsoft.Maps.Events.addHandler(layer, 'click', displayInfoboxClick);
        // Microsoft.Maps.Events.addHandler(layer, 'dblclick', displayInfoboxDoubleClick);
        thisRef._bingMap.layers.insert(layer);
        // debugger;
        this._bingMap.setView({
            zoom: 1 || 0
        });

        function getRandomArbitrary(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        function createSinglePushpin(data, maxValue) {
            var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(data.loc.latitude, data.loc.longitude), {});
            //Store a reference to the data in the metadata of the pushpin for access later.
            pin.metadata = data;
            return pin;
        }

        function createScaledImagePushpin(imgUrl, scale, callback, data, maxValue) {
            var img = new Image();
            img.onload = function () {
                var c = document.createElement('canvas');
                c.width = 50;
                c.height = 50;
                var context = c.getContext('2d');
                //Draw scaled image
                context.drawImage(img, 0, 0, c.width, c.height);
                var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(data.loc.latitude, data.loc.longitude), {
                    //Generate a base64 image URL from the canvas.
                    icon: c.toDataURL(),
                    //Anchor based on the center of the image.
                    anchor: new Microsoft.Maps.Point(c.width / 2, c.height / 2)
                });
                pin.metadata = data;
                if (callback) {
                    callback(pin);
                }
            };
            img.src = imgUrl;
        }

        function getCountNotNullIndexes(data) {
            var __validEleCount = 0;
            data.values.forEach((_datValue: any, _datKey: any) => {
                if (_datValue != null && _datValue != undefined) {
                    __validEleCount++;
                }
            });
            return __validEleCount > 1 && data.values.length > 1;
        }

        function createPieChartPushpin(data, maxValue) {
            // thisRef._chartOptions.maxRadius = 30;
            // thisRef._chartOptions.maxRadius = thisRef._chartOptions.maxRadius * data.values.length;
            var startAngle = 0, angle = 0;
            var radius = Math.round(Math.max(data.total / maxValue * thisRef._chartOptions.pieChart.maxRadius, thisRef._chartOptions.pieChart.minRadius));
            var diameter = 2 * (radius + thisRef._chartOptions.strokeThickness);
            var svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="', diameter, 'px" height="', diameter, 'px">'];
            var cx = radius + thisRef._chartOptions.strokeThickness,
                cy = radius + thisRef._chartOptions.strokeThickness;

            if (_valueList.length != 0 && getCountNotNullIndexes(data)) {
                for (var i = 0; i < data.values.length; i++) {
                    angle = (Math.PI * 2 * (data.values[i] / data.total));
                    svg.push(createArc(cx, cy, radius, startAngle, angle, thisRef._chartOptions.colors[i]));
                    startAngle += angle;
                }
            }
            else {
                for (var i = 0; i < data.values.length; i++) {
                    svg.push('<circle cx="' + cx + '" cy="' + cy + '" r="' + radius + '" fill="' +
                        thisRef._chartOptions.colors[getRandomArbitrary(0, thisRef._chartOptions.colors.length - 1)] + '" />');
                }
            }
            svg.push('</svg>');
            var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(data.loc.latitude, data.loc.longitude), {
                icon: svg.join(''),
                anchor: new Microsoft.Maps.Point(cx, cy),
            });
            //Store a reference to the data in the metadata of the pushpin for access later.
            pin.metadata = data;
            return pin;
        }

        function createColumnChartPushpin(data, maxValue) {
            // thisRef._chartOptions.maxHeight = 250;
            // thisRef._chartOptions.maxHeight = thisRef._chartOptions.maxHeight * thisRef._masterMapChartRecords.length;
            var width = data.values.length * thisRef._chartOptions.barWidth;
            var svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="', width, 'px" height="', thisRef._chartOptions.maxHeight, 'px">'];
            var x, y, h;
            for (var i = 0; i < data.values.length; i++) {
                //Calculate the height of the bar in pixels.
                h = Math.min(data.values[i] / maxValue * thisRef._chartOptions.maxHeight, thisRef._chartOptions.maxHeight);
                //Calculate the x offset of the bar.
                x = i * thisRef._chartOptions.barWidth;
                //Calculate the y offset of the bar such that the bottom aligns correctly.
                y = thisRef._chartOptions.maxHeight - h;
                if (data.values.length == 1) {
                    i = getRandomArbitrary(0, thisRef._chartOptions.colors.length - 1);
                }
                svg.push('<rect x="', x, 'px" y="', y, 'px" width="', thisRef._chartOptions.barWidth, 'px" height="', h, 'px" fill="', thisRef._chartOptions.colors[i], '"/>');
            }
            svg.push('</svg>');
            var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(data.loc.latitude, data.loc.longitude), {
                icon: svg.join(''),
                anchor: new Microsoft.Maps.Point(width / 2, thisRef._chartOptions.maxHeight)
            });
            //Store a reference to the data in the metadata of the pushpin for access later.
            pin.metadata = data;
            return pin;
        }

        function createArc(cx, cy, r, startAngle, angle, fillColor) {
            var x1 = cx + r * Math.sin(startAngle);
            var y1 = cy - r * Math.cos(startAngle);
            var x2 = cx + r * Math.sin(startAngle + angle);
            var y2 = cy - r * Math.cos(startAngle + angle);
            //Flag for when arcs are larger than 180 degrees in radians.
            var big = 0;
            if (angle > Math.PI) {
                big = 1;
            }
            var path = ['<path d="M ', cx, ' ', cy, ' L ', x1, ' ', y1, ' A ', r, ',', r, ' 0 ', big, ' 1 ', x2, ' ', y2,
                ' Z" style="fill:', fillColor,
                ';stroke:', thisRef._chartOptions.strokeColor,
                ';stroke-width:', thisRef._chartOptions.strokeThickness,
                'px;"'];
            path.push('/>');
            return path.join('');
        }

        function displayInfoboxMouseOut(e) {
            thisRef._bingInfobox.setOptions({
                location: e.target.getLocation(),
                visible: false
            });
        }

        function displayInfoboxMouseOver(e) {
            var data = e.target.metadata;
            var description = [''];
            var minHieght = data.values ? data.values.length >= 2 ? '100px' : '65px' : '45px';
            var infoboxTemplate = '<div id="infoboxText" style="background-color:White; border-style:solid; border-width:medium; border-color:DarkOrange; min-height:' + minHieght + '; width: 240px; border-width:2px;border-radius:5px;">' +
                '<b id="infoboxTitle" style="position: absolute; top: 10px; left: 10px; width: 220px;">{title}</b>' +
                '<a id="infoboxDescription" style="height: 66px;overflow: auto; position: absolute; top: 30px; left: 16px; width: 220px;">{description}</a></div>';


            // description.push('</table>');
            thisRef._bingInfobox.setOptions({
                location: e.target.getLocation(),
                visible: true,
                htmlContent: infoboxTemplate.replace('{title}', data.name).replace('{description}', description.join('')),
                width: 300,
                showCloseButton: true
            });
        }




    }
}

