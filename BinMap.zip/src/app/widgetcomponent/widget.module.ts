import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { WidgetcomponentComponent } from './widgetcomponent.component';
import { MapChartWidgetDirective } from '../map-directive';
import { BingApiLoaderService } from '../bingmap-api-loader-service';
import { WINDOW_PROVIDERS } from '../window-service';


@NgModule({
    declarations: [
        WidgetcomponentComponent,
        MapChartWidgetDirective,
    ],
    imports: [
        BrowserModule
    ],
    exports: [
        WidgetcomponentComponent
    ],
    providers: [
        BingApiLoaderService,
        WINDOW_PROVIDERS
    ],
    bootstrap: [WidgetcomponentComponent]
})
export class WidgetModule { }
