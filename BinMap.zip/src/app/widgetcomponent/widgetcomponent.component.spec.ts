import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WidgetcomponentComponent } from './widgetcomponent.component';

describe('WidgetcomponentComponent', () => {
  let component: WidgetcomponentComponent;
  let fixture: ComponentFixture<WidgetcomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WidgetcomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WidgetcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
