import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input } from '@angular/core';
import { BingApiLoaderService } from '../bingmap-api-loader-service';


@Component({
  selector: 'app-widgetcomponent',
  templateUrl: './widgetcomponent.component.html',
  styleUrls: ['./widgetcomponent.component.scss']
})
export class WidgetcomponentComponent implements OnInit {
  @Input() id;
  title = 'bingMapApi';
  @ViewChild('widgetContainer', { read: ViewContainerRef, static: true }) widgetContainerRef: ViewContainerRef;
  @ViewChild('mapChartTemplate', { read: TemplateRef, static: true }) mapChartTemplate: TemplateRef<any>;
  config: any = {
    mapInfo: '1'
  };
  constructor(
    public _load: BingApiLoaderService
  ) {

  }

  mapChartEvents(ev) {

  }

  async ngOnInit() {
    this.config.cardId = this.id;
    await this.loadMapWidget();
    this.loadMap();
  }

  async loadMapWidget() {
    this.widgetContainerRef.createEmbeddedView(this.mapChartTemplate, {
      $implicit: { config: this.config }
    })


  }

  loadMap() {
    
  }
}
