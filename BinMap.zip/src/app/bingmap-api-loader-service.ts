import { Injectable, Inject } from '@angular/core';

import { DOCUMENT } from '@angular/common';
import { WINDOW } from './window-service';


@Injectable()

export class BingApiLoaderService {

    private _bingMapPromise: any;
    private _bingMapUrls: any;
    constructor(

        @Inject(DOCUMENT) private _documentRef: Document,
        @Inject(WINDOW) private _windowRef: Window
    ) {

    }
    /**
     * Loading the bing maps and adding the API Keys dynamically and loading the files 
     * for the executions purpose.
     */
    public LoadMaps(): Promise<any> {
        console.log('Maps');
        this._bingMapUrls = "https://www.bing.com/api/maps/mapcontrol?callback=__onBingLoaded&key=AkKDako88ToRKIXgxCNAL5mS06oEJ6UhujH4-CV3WgMLGdhFGnSLxoiQMon4LfBh";
        // First time 'load' is called?
        if (!this._bingMapPromise) {
            // Make promise to load
            this._bingMapPromise = new Promise(resolve => {

                // Set callback for when bing maps is loaded.
                this._windowRef['__onBingLoaded'] = (ev) => {
                    resolve('Bing Maps API loaded');
                };

                // const node = document.createElement('script');
                const _loadingScripts = this._documentRef.createElement('script');
                _loadingScripts.src = this._bingMapUrls;
                _loadingScripts.type = 'text/javascript';
                _loadingScripts.async = true;
                _loadingScripts.defer = true;
                _loadingScripts.charset = "utf-8";
                // _documentRef.getElementsByTagName('head')[0].appendChild(node);
                this._documentRef.getElementsByTagName('head')[0].appendChild(_loadingScripts);
            });
        }

        // Always return promise. When 'load' is called many times, the promise is already resolved.
        return this._bingMapPromise;
    }
}
